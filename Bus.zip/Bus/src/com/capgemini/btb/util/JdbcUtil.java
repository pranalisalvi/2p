package com.capgemini.btb.util;



import java.util.Properties;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.btb.exception.BookingException;

public class JdbcUtil {

private static final Logger mylogger=

Logger.getLogger(JdbcUtil.class);

public static Properties loadProperty(){

Properties prop= new Properties();

InputStream in = null;

try {

in= new FileInputStream("emp.properties");

} catch (FileNotFoundException e) {

e.printStackTrace();

}

try {

prop.load(in);

} catch (IOException e) {

e.printStackTrace();

}

finally{

try {

in.close();

} catch (IOException e) {

e.printStackTrace();

}

}

return prop;

}

public static Connection getConnection() throws BookingException {

String url, usernm, pass, driver;

Connection con= null;

Properties prop= loadProperty();

driver= prop.getProperty("oracle.driver");

url= prop.getProperty("oracle.url");

usernm= prop.getProperty("oracle.uname");

pass= prop.getProperty("oracle.upass");

//PropertyConfigurator.configure("log4j.properties");

try {

Class.forName(driver);

mylogger.info("Driver loaded");

} catch (ClassNotFoundException e) {

// TODO Auto-generated catch block

e.printStackTrace();

mylogger.error("Driver not loaded");

}

try {

con= DriverManager.getConnection(url, usernm, pass);

mylogger.info("Connected to database");

} catch (SQLException e) {

// TODO Auto-generated catch block

//e.printStackTrace();

mylogger.error("Not connected");

throw new BookingException("Connection problem");

}

return con;

}

}
