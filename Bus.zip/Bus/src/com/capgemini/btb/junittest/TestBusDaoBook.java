package com.capgemini.btb.junittest;

import static org.junit.Assert.*;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;

import com.capgemini.btb.bean.BookingBean;

import com.capgemini.btb.dao.BusDaoImpl;

import com.capgemini.btb.dao.IBusDao;

import com.capgemini.btb.exception.BookingException;

public class TestBusDaoBook {

	IBusDao ibus;

	@Before
	public void setUp() throws Exception {

		ibus = new BusDaoImpl();

	}

	@After
	public void tearDown() throws Exception {

		ibus = null;

	}

	@Test
	public void testBookTicket() {

		BookingBean book = new BookingBean(3, 2, "A121111");

		try {

			int res = ibus.bookTicket(book);

			assertEquals(1, res);

		} catch (BookingException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}

}
