package com.capgemini.btb.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.btb.bean.BookingBean;

import com.capgemini.btb.bean.BusBean;

import com.capgemini.btb.exception.BookingException;

import com.capgemini.btb.util.JdbcUtil;

import java.sql.*;

public class BusDaoImpl implements IBusDao {

	private static final Logger mylogger =

	Logger.getLogger(BusDaoImpl.class);

	Connection con;

	PreparedStatement psmt1, psmt2, psmt3, psmt4, psmt5, psmt6;

	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {

		PropertyConfigurator.configure("log4j.properties");

		con = JdbcUtil.getConnection();

		ArrayList<BusBean> busList = new ArrayList<BusBean>();

		String selQry = "SELECT * FROM BusDetails";

		try {

			psmt1 = con.prepareStatement(selQry);

			ResultSet rs = psmt1.executeQuery();

			while (rs.next()) {

				int b_Id = rs.getInt(1);

				String b_Type = rs.getString(2);

				String frm_Stop = rs.getString(3);

				String to_Stop = rs.getString(4);

				int fare = rs.getInt(5);

				int avlbl_Seats = rs.getInt(6);

				Date dt = rs.getDate(7);

				BusBean bus = new BusBean();

				bus.setBusId(b_Id);

				bus.setBusType(b_Type);

				bus.setFromStop(frm_Stop);

				bus.setToStop(to_Stop);

				bus.setFare(fare);

				bus.setAvailableSeats(avlbl_Seats);

				busList.add(bus);

			}

			mylogger.info("Displayed all available buses");

		} catch (SQLException e) {

			mylogger.error("Data not found");

			e.printStackTrace();

			throw new BookingException("No data found");

		}

		finally {

			try {

				con.close();

			} catch (SQLException e) {

				e.printStackTrace();

			}

		}

		return busList;

	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {

		PropertyConfigurator.configure("log4j.properties");

		con = JdbcUtil.getConnection();

		int rec = 0;

		int available_seat = 0;

		String cus_id = bookingBean.getCustId();

		int bus_id = bookingBean.getBusId();

		int seats = bookingBean.getNoOfSeat();

		String chkBus = "SELECT busId FROM BusDetails";

		try {

			psmt5 = con.prepareStatement(chkBus);

			ResultSet rs = psmt5.executeQuery();

			while (rs.next()) {

				int i = 0;

				int chkBusid = rs.getInt(1);

				if (chkBusid == bus_id) {

					break;

				}

				i++;

			}

		} catch (SQLException e1) {

			// TODO Auto-generated catch block

			e1.printStackTrace();

			throw new BookingException("Bus Id might be wrong");

		}

		String val = "SELECT availableSeats FROM BusDetails WHERE busId=?";

		String insQry = "INSERT INTO BookingDetails VALUES(Booking_Id_Seq.NEXTVAL,?,?,?)";

		try {

			psmt2 = con.prepareStatement(val);

			psmt2.setInt(1, bus_id);

			ResultSet rs = psmt2.executeQuery();

			while (rs.next()) {

				available_seat = rs.getInt(1);

				System.out.println("Available seats :" + available_seat);

			}

			if (available_seat >= seats) {

				psmt3 = con.prepareStatement(insQry);

				psmt3.setString(1, cus_id);

				psmt3.setInt(2, bus_id);

				psmt3.setInt(3, seats);

				rec = psmt3.executeUpdate();

				if (rec > 0) {

					String getBookId = "SELECT bookingId FROM BookingDetails WHERE custId=?";

					psmt4 = con.prepareStatement(getBookId);

					psmt4.setString(1, cus_id);

					ResultSet rs2 = psmt4.executeQuery();

					while (rs2.next()) {

						int book_id = rs2.getInt(1);

						bookingBean.setBookingId(book_id);

					}

					mylogger.info("Booking done successfully");

					String updateQry = "UPDATE BusDetails SET availableSeats=? WHERE busId=?";

					psmt6 = con.prepareStatement(updateQry);

					int newSeats = available_seat - seats;

					psmt6.setInt(1, newSeats);

					psmt6.setInt(2, bus_id);

					int upd_rc = psmt6.executeUpdate();

					if (upd_rc > 0) {

						http: // mylogger.info("No of seats updated successfully");

						System.out.println("No. of seats updated: " + newSeats);

					}

					else {

						mylogger.error("Updation of seats failed.");

						throw new BookingException("Updation of seats failed");

					}

					return 1;

				}

			}

			else {

				mylogger.error("Booking failed.");

				throw new BookingException("Sorry, no seats are available");

			}

		}

		// }

		catch (SQLException e) {

			e.printStackTrace();

		}

		finally {

			try {

				con.close();

			} catch (SQLException e) {

				// TODO Auto-generated catch block

				e.printStackTrace();

			}

		}

		return 0;

	}

}