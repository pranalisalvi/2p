import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;


public class Demo {

	
		public static void writeProperties()
		{
			Properties prop=new Properties();
			OutputStream output=null;
			try{
				output=new FileOutputStream("oracle.properties");
			prop.setProperty("oracle.driver", "oracle.jdbc.driver.OracleDriver");
			prop.setProperty("oracle.url","jdbc:oracle:thin:@localhost:1521:xe");
			prop.setProperty("oracle.uname","labg104trg8@orcl11g");
			prop.setProperty("oracle.upass","labg104oracle");
			
			prop.store(output,null);
			}catch(IOException io){
				io.printStackTrace();
			}finally{
				if(output !=null){
					try{
						output.close();
					}catch(IOException e){
						e.printStackTrace();
				}
			
		}
	}

}
		
public static void loadProperties(){
	Properties prop=new Properties();
	InputStream input=null;
	try{
		input=new FileInputStream("oracle.properties");
		prop.load(input);
		System.out.println(prop.getProperty("oracle.driver"));
		System.out.println(prop.getProperty("oracle.url"));
		System.out.println(prop.getProperty("oracle.uname"));
		System.out.println(prop.getProperty("oracle.upass"));
	}catch(IOException io){
		io.printStackTrace();
	}finally{
		if(input !=null){
			try{
				input.close();
			}catch(IOException e){
				e.printStackTrace();
		}
	
}
}
		
		
		
}


public static void main(String[] args){
	writeProperties();
	loadProperties();
}
}
