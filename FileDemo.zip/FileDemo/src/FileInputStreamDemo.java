
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamDemo {

	public static void main(String[] args) {
		
		try(FileInputStream in=new	FileInputStream("d:\\word.txt")) {
			int ch=in.read();
			while(ch!=-1){
				System.out.print((char)ch); // o/p comes in binary so do downcasting
				ch=in.read();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

}
