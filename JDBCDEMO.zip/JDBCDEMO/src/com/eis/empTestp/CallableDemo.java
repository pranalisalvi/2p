package com.eis.empTestp;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.eis.empl.JdbcUtil;

public class CallableDemo {
	public static void main(String[] args) {
		Connection con=null;
		CallableStatement cst=null;
		String query="{call getsal(?,?)}";
		
		try {
			con=JdbcUtil.getConnection();
			cst=con.prepareCall(query);
			cst.setInt(1, 105);
			cst.registerOutParameter(2,java.sql.Types.INTEGER);
			cst.execute();
			int employee_salary=cst.getInt(2);
			System.out.println(employee_salary);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
}
}
