package com.eis.empTest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.eis.empl.JdbcUtil;

public class JdbcTest {
	public static void main(String[] args) {
		Connection con=null;
		con=JdbcUtil.getConnection();
		PreparedStatement pst=null;
		if(con!=null){
			System.out.println("connected");
			String insertQuery="insert into dept values(?,?,?)";
			try {
				pst=con.prepareStatement(insertQuery);
				pst.setInt(1,90);
				pst.setString(2,"COMPUTER");
				pst.setString(3, "India");
				int rec=pst.executeUpdate();
				System.out.println(rec);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}


			
		}
		
	}
}
