import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Ex1 {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String url="jdbc:Oracle:thin:@10.125.6.62:1521:ORCL11G";
		try(Connection con=DriverManager.getConnection(url, "labg104trg8", "labg104oracle")){
		if(con!=null){
			/*System.out.println("connected");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from dept");
			while(rs.next()){
				//int deptno=rs.getInt(1);
				System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
				
			}*/
			
			Statement st=con.createStatement();
			//int rec=st.executeUpdate("insert into dept values(70,'Computer','India')");
			//int rec=st.executeUpdate("delete from dept where deptno=70");
			int rec=st.executeUpdate("update  dept set loc='India' where deptno=10");
					System.out.println("no of record"+rec);
		}

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}
}

	
