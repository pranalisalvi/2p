package com.cg.eis.service;

import java.util.*;

import com.cg.eis.bean.Employee;

import com.cg.eis.util.JdbcUtil;

import java.sql.*;

public class EmpServiceImpl implements IEmployeeService {

	Scanner sc = new Scanner(System.in);

	Scanner sc2 = new Scanner(System.in);

	public void inputEmployee() {

		String enm;

		String eid;

		double esal;

		String eDesg;

		String eIns;

		int rec;

		Employee empl = new Employee();

		System.out.println("Enter Employee ID");

		eid = sc.nextLine();

		System.out.println("Enter Employee name");

		enm = sc.nextLine();

		System.out.println("Enter Employee salary");

		esal = sc.nextDouble();

		System.out.println("Enter Employee designation");

		eDesg = sc2.nextLine();

		empl.setId(eid);

		empl.setName(enm);

		empl.setSalary(esal);

		empl.setDesg(eDesg);

		empl.setInsaurance_Sch(esal, eDesg);

		eIns = empl.getInsaurance_Sch();

		Connection con = null;

		PreparedStatement pst;

		con = JdbcUtil.getConnection();

		String insQry = "insert into empDetail values(?,?,?,?,?)";

		try {

			pst = con.prepareStatement(insQry);

			pst.setString(1, eid);

			pst.setString(2, enm);

			pst.setDouble(3, esal);

			pst.setString(4, eDesg);

			pst.setString(5, eIns);

			rec = pst.executeUpdate();

			if (rec > 0) {

				System.out.println("Insert done!!");

			}

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}

	public void deleteEmp() {

		System.out.println();

		Connection con = null;

		PreparedStatement pst2;

		con = JdbcUtil.getConnection();

		System.out.println("Enter insurance scheme to delete");

		String ins = sc2.nextLine();

		String dltQry = "delete from empDetail where Insaurance_Sch=?";

		try {

			pst2 = con.prepareStatement(dltQry);

			pst2.setString(1, ins);

			int rec = pst2.executeUpdate();

			if (rec > 0) {

				System.out.println("Delete done!!");

			}

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		System.out.println();

		System.out.println();

		System.out.println("After Deleting :");

		PreparedStatement pst3;

		String show = "select * from empDetail";

		try {

			pst3 = con.prepareStatement(show);

			ResultSet rs = pst3.executeQuery();

			while (rs.next()) {

				System.out.print(rs.getString(1) + " ");

				System.out.print(rs.getString(2) + " ");

				System.out.print(rs.getInt(3) + " ");

				System.out.print(rs.getString(4) + " ");

				System.out.print(rs.getString(5) + " ");

				System.out.println();

			}

			System.out.println();

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}

	public void showAllEmp() {

		Connection con = null;

		PreparedStatement pst4;

		con = JdbcUtil.getConnection();

		String show = "select * from empDetail";

		System.out.println("Showing all employee details:");

		try {

			pst4 = con.prepareStatement(show);

			ResultSet rs = pst4.executeQuery();

			ResultSetMetaData rsmd = rs.getMetaData();

			System.out
					.println(rsmd.getColumnName(1) + " "
							+ rsmd.getColumnName(2) + " "
							+ rsmd.getColumnName(3) + " "
							+ rsmd.getColumnName(4) + " "
							+ rsmd.getColumnName(5) + " ");

			while (rs.next()) {

				System.out.print(rs.getString(1) + " ");

				System.out.print(rs.getString(2) + " ");

				System.out.print(rs.getInt(3) + " ");

				System.out.print(rs.getString(4) + " ");

				System.out.print(rs.getString(5) + " ");

				System.out.println();

			}

			System.out.println();

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}

}
