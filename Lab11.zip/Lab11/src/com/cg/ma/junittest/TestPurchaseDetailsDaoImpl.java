package com.cg.ma.junittest;

import static org.junit.Assert.*;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IMobileDao;

import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.exception.PurchaseDetailsException;

public class TestPurchaseDetailsDaoImpl {
	IMobileDao iMobile;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {

	}
	
	@Before
	public void setup() {
		iMobile=new MobileDaoImpl();  //add this code
	}


	@Test
	public void testInsertPurchaseDetails() {
		try {
			//assertNotNull(ipurchase.insertPurchaseDetails("Pranali","pranali.94@gmail.com","9823234534",1001));
			assertEquals(true,iMobile.insertPurchaseDetails("Pranali","pranali.94@gmail.com","9823234534",1001));
		} catch (PurchaseDetailsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@After
	public void tearDown() throws Exception {
	}

}
