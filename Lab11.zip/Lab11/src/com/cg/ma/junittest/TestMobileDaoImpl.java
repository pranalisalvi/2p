package com.cg.ma.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.exception.MobileException;

public class TestMobileDaoImpl {
	IMobileDao iMobile;            //declare local varaible

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

	}

	@Before
	public void setup() {
		iMobile = new MobileDaoImpl();  //add this code
	}

	@Test
	public void testShowAll() {
		try {
			assertNotNull(iMobile.showAll());  //add this code  //try catch after exception write in impl
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@After
	public void tearDown() throws Exception {
		iMobile = null;                       //add this code
	}

}
