package com.cg.ma.junittest;

import static org.junit.Assert.*; 

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.exception.MobileException;

public class Test2MobileDaoImpl {
	IMobileDao iMobile;     
	@AfterClass
	public static void tearDownAfterClass() throws Exception {

	}

	@Before
	public void setup() {
		iMobile = new MobileDaoImpl();  //add this code
	}


	@Test
	public void testDeleteMobile() throws MobileException {
		assertEquals(true,iMobile.deleteMobile(1003) );
	}

	@Test
	public void testSearchByRange() throws MobileException {
		assertNotNull(iMobile.searchByRange(8000, 30000));
	}

	@Test
	public void testUpdateQty() throws MobileException {
		assertEquals(true,iMobile.updateQty(1005,3));
		
	}
	
	@After
	public void tearDown() throws Exception {
		iMobile=null;
	}

}
