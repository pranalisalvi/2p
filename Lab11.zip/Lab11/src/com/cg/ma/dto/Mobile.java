package com.cg.ma.dto;

public class Mobile {
	

	private int mobileid;
	private String name;
	private double price;
	private int quantity;

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Mobile() {
		super();
	}

	public Mobile(int mobileid, String name, double price, int quantity) {
		super();
		this.mobileid = mobileid;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Mobile [mobileid=" + mobileid + ", name=" + name + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	
}
