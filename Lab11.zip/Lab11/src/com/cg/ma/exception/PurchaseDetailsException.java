package com.cg.ma.exception;

public class PurchaseDetailsException extends Exception {
	public	PurchaseDetailsException(String msg){
		super(msg);
	}
}
