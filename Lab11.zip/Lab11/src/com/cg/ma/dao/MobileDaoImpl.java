package com.cg.ma.dao;

import java.sql.Connection; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.exception.MobileException;
import com.cg.ma.exception.PurchaseDetailsException;
import com.cg.ma.util.JdbcUtil;

public class MobileDaoImpl implements IMobileDao  {
Connection con;        //1.not null bcz in class not method
PreparedStatement pst;  //2.

private static final Logger mylogger=                            //create obj of Logger
Logger.getLogger(MobileDaoImpl.class);


	public List<Mobile> showAll() throws MobileException {
		con=JdbcUtil.getConnection();  //3.call getConnetion method
		String query="SELECT * FROM mobiles";    //4.do query
		List<Mobile>mList=new ArrayList<Mobile>();  //*this we create obj of ArrayList to store values
		try {
			
			pst=con.prepareStatement(query);     //5.put query in prepared statement  after this line error comes, so put try catch
			ResultSet rs=pst.executeQuery();     //6.after try catch write this line next to pst
			while(rs.next()){					//7.
				int m_id=rs.getInt(1);			//8.
				String m_name=rs.getString(2);	
				double m_price=rs.getInt(3);
				int m_qty=rs.getInt(4);
				
				Mobile m=new Mobile();      //create obj of Mobile
				m.setMobileid(m_id);        //set local variable
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);      //to store this value require ArrayList
				mList.add(m);				//store value
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//throw user defined exception
			throw new MobileException("Data not found");
		}
		  return mList;						//return value
		
	}

	public boolean deleteMobile(int mobileid) throws MobileException {
		con=JdbcUtil.getConnection();
		int rec=0;
		String query="DELETE FROM mobiles WHERE mobileid=?";
		
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1, mobileid);
			rec=pst.executeUpdate();
			if(rec>0)
				mylogger.info("Data is deleted"); 
				return true;
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.error(" Data of mobile Not deleted");
			
			
		}finally{                           //  after catch write false
			try {
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new MobileException("Data not deleted");
			}
		}
		return false;
	}

	public List<Mobile> searchByRange(int start, int end) throws MobileException {
		con=JdbcUtil.getConnection();
		String query="SELECT * FROM mobiles WHERE price >=? AND price <=?";
		List<Mobile>mList=new ArrayList<Mobile>(); 
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1, start);
			pst.setInt(2, end);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				int m_id=rs.getInt(1);
				String m_name=rs.getString(2);
				double m_price=rs.getInt(3);
				int m_qty=rs.getInt(4);
				
				Mobile m=new Mobile();      //create obj of Mobile
				m.setMobileid(m_id);        //set local variable
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);      //to store this value require ArrayList
				mList.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("data not found");
		}
		return mList;
		
	}

	public boolean updateQty(int mobileid, int qty) throws MobileException {
		con=JdbcUtil.getConnection();
		int rec=0;
		String query="UPDATE mobiles SET quantity=quantity-? WHERE mobileid=?";
		
		try {          
			pst=con.prepareStatement(query);
			pst.setInt(1, qty);
			pst.setInt(2,mobileid);
			rec=pst.executeUpdate();
			if(rec >0){
				mylogger.info("Data is updated");
				return true;
			}	                                 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.error(" Data Not updated");
			
			
			throw new MobileException("data is not updated");
		}
		return false;
	}
	
	public boolean insertPurchaseDetails(String cust_name, String cust_mail,
			String cust_phone, int mobileid) throws PurchaseDetailsException {
		
		try {
			con=JdbcUtil.getConnection(); //4.call getConnetion method
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		int qty=0;                     //11.qty declare
		int rec=0;
		String iquery="INSERT INTO PurchaseDetails VALUES(purchase_seq.NEXTVAL,?,?,?,sysdate,?)";  //5.write query
		String squery="SELECT quantity FROM mobiles WHERE mobileid=?";
		try {
			  
			pst=con.prepareStatement(squery);  //6.after this line try catch,& below this line put code
			pst.setInt(1, mobileid);           	//7.
			ResultSet rs=pst.executeQuery();    //8
			while(rs.next()){                   //9.
				qty=rs.getInt(1);               //10.to check qty is greater than 0,first take qty by get()then do insert
				//System.out.println("existing quantity :"+qty);
			}
			
			if(qty> 0){
				
				pst=con.prepareStatement(iquery);
				pst.setString(1, cust_name);
				pst.setString(2, cust_mail);
				pst.setString(3, cust_phone);
				pst.setInt(4, mobileid);
				
				PurchaseDetails pd=new PurchaseDetails();
				pd.setCname(cust_name);
				pd.setMailid(cust_mail);
				pd.setPhoneno(cust_phone);
				pd.setMobileid(mobileid);
				
				rec=pst.executeUpdate();
				if(rec>0){
					mylogger.info("Data is inserted");
					return true;
				}
				
				
				
			}
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.error("Data is not inserted");
			
			throw new PurchaseDetailsException("data not inserted");
			
		}
		
		return false;
	}

	
	
	
	public boolean Mobileid(int mid) throws MobileException{
		int id=0;
		String query="SELECT count(mobileid) FROM mobiles WHERE mobileid=?";
		con=JdbcUtil.getConnection();
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1,mid);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				id=rs.getInt(1);
			}
			if(id==1){
				return true;
			}
			else{
				throw new MobileException("mobile id not exist");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e);
		
		}
		return false;
		
	}

	
	
	
	
	
	
	
/*	public static void main(String[] args) throws MobileException{      //this code is only for manual testing
		MobileDaoImpl impl=new MobileDaoImpl();
		//List<Mobile>mList=impl.showAll();
		List<Mobile>mList=impl.searchByRange(8000, 30000);
		
		for(Mobile m:mList){
			System.out.println(m);
		}
		//System.out.println(impl.deleteMobile(1007));
		//System.out.println(impl.deleteMobile(1008));
	}*/
	

}
