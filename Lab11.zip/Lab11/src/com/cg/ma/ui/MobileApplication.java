package com.cg.ma.ui;

import java.util.List; 
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;
import com.cg.ma.exception.PurchaseDetailsException;
import com.cg.ma.service.IMobileService;

import com.cg.ma.service.MobileServiceImpl;

import com.cg.ma.util.JdbcUtil;

public class MobileApplication {
	private static final Logger mylogger=                //create obj of logger
			Logger.getLogger(MobileApplication.class);
	
	
	public static void main(String[] args) throws MobileException, PurchaseDetailsException{
		
		 PropertyConfigurator.configure("log4j.properties");   //this line add for logger msg
		 mylogger.info("Application started");                  //this also
		 System.out.println("start");                          //this also  fr start
		
		 
		 IMobileService service=new MobileServiceImpl();
		//IPurchaseDetailsService pservice=new  PurchaseDetailsServiceImpl();
		
		int choice=0;
		do{
			printDetail();
			Scanner sc=new Scanner(System.in);
			choice=sc.nextInt();
			switch(choice){
			case 1:
				List<Mobile> mList =service.showAllMobiles();
				for(Mobile m:mList){
					System.out.println("mobileid ="+m.getMobileid()+"mobile name ="+m.getName()+"price ="+m.getPrice()+"quantity="+m.getQuantity());
					
				}
				break;
				
			case 2:
				
				System.out.println("enter minimum price");
				int start=sc.nextInt();
				System.out.println("ENTER MAXIMUM PRICE");
				int end=sc.nextInt();
				List<Mobile> mList1=service.searchMobileByRange( start, end);
				for(Mobile m:mList1){
					System.out.println("mobileid ="+m.getMobileid()+"mobile name"+m.getName()+"price ="+m.getPrice()+"quantity="+m.getQuantity());
					
				}
				break;
				
			case 3:
				/*boolean chkmid=false;
				
				String regName="[A-Z]+[a-z]{1,19}";
				String regEmail="(.+)@(.+)[.]{1}(.+)$";
				String regPhone="[7|9|8]{1}[0-9]{9}";
				String regMoid="^[1-9]{1}[0-9]{3}";
				
				System.out.println("enter customer name");
				String cname=sc.next();
				System.out.println("enter email id");
				String mailid=sc.next();
				System.out.println("enter phone no");
				String phoneno=sc.next();
				System.out.println("enter mobile id");
				String mobileid=sc.next();
				
				
				boolean chkname=Pattern.matches(regName, cname);
				boolean chkmail=Pattern.matches(regEmail, mailid);
				boolean chkphone=Pattern.matches(regPhone, phoneno);
				chkmid=Pattern.matches(regMoid, mobileid);
				
				int mid=Integer.parseInt(mobileid);
				if(chkmid==true){
					chkmid=service.Mobileid(mid);
				}
				
				if((chkname==true)&&(chkmail==true)&&(chkphone==true)&&(chkmid==true)){
					pservice.insertPurchaseDetails(cname, mailid, phoneno, mid);
					System.out.println("successfully data added");
					service.updateQty(mid, 1);
				}
				else{
					System.out.println("customer name="+chkname+"email id="+chkmail+"contact no="+chkphone+"mobile id="+chkmid);
				    System.out.println("please enter proper customer details");
				}
				    break;*/
				    
				
				boolean chkmid=false;
				boolean chkname;
				boolean chkmail;
				boolean chkphone;
			
				
				String cname;
				String mailid;
				String phoneno;
				String mobileid;
				

				String regName="[A-Z]+[a-z]{1,19}";
				String regEmail="(.+)@(.+)[.]{1}(.+)$";
				String regPhone="[7|9|8]{1}[0-9]{9}";
				String regMoid="^[1-9]{1}[0-9]{3}";
				
				do{

					System.out.println("enter customer name");
				    cname=sc.next();
					chkname=Pattern.matches(regName, cname);
				}while(chkname!=true);
				
				do{
					System.out.println("enter email id");
					 mailid=sc.next();
				  chkmail=Pattern.matches(regEmail, mailid);
				}while(chkmail!=true);
				
				do{
					System.out.println("enter phone no");
				    phoneno=sc.next();
				    chkphone=Pattern.matches(regPhone, phoneno);
				}while(chkphone!=true);
				
				do{
					System.out.println("enter mobile id");
				    mobileid=sc.next();
					chkmid=Pattern.matches(regMoid, mobileid);
					
					
				}while(chkmid!=true);
				
				int mid=Integer.parseInt(mobileid);
				if(chkmid==true){
					chkmid=service.Mobileid(mid);
				}
				if((chkname==true)&&(chkmail==true)&&(chkphone==true)&&(chkmid==true)){
					service.insertPurchaseDetails(cname, mailid, phoneno, mid);
					System.out.println("successfully data added");
					service.updateQty(mid, 1);
				}
				else{
					System.out.println("customer name="+chkname+"email id="+chkmail+"contact no="+chkphone+"mobile id="+chkmid);
				    System.out.println("please enter proper customer details");
				}
		
				
				
				
				    break;
				    
				
			case 4:
				System.out.println("enter mobile id");
				int mobileid1=sc.nextInt();
				System.out.println("enter purchase quantity");
				int qty=sc.nextInt();
				service.updateQty(mobileid1, qty);
				System.out.println("mobile quantity updated");
				
				break;
				
			case 5:	
				System.out.println("enter mobile id");
				int mid2=sc.nextInt();
				boolean str=service.deleteMobile(mid2);
				if(str==true){
					System.out.println("mobile detail deleted");
				}
				break;
			case 6:
				
				 PropertyConfigurator.configure("log4j.properties");   //this line add for logger msg
				 mylogger.info("Application ended");                  //this also
				 System.out.println("end");                          //for end
				break;
			             
			default:
				System.out.println("enter choice between 1 to 5");
			}//end of switch
		}while(choice!=6);    //end of do
		
	}//end of main metod
	
		public static void printDetail(){
			System.out.println("**********");
			System.out.println("select choice");
			System.out.println("1.show all mobile details  ");
			System.out.println("2. Search mobile");
			System.out.println("3. insert customer and purchase details");
			System.out.println("4. update mobile quantity ");
			System.out.println("5.delete mobile details");
			System.out.println("6. Exit");
			System.out.println("***********");
	}
}//end of class
