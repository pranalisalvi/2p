package lab9_2;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DateTest {
 

	@Test
	public void testReturn() {
		System.out.println("from testReturn");
		Date td=new Date(23,2,2017);
		assertEquals("Date is:23/2/2017",td.toString());
		
		assertNotNull(td);
	}

	@Test
	public void testgetDay() {
		System.out.println("from testGetDay");
		Date td=new Date(23,2,2017);
		assertEquals(23,td.getIntDay());
		
	}

	@Test
	public void testgetMonth() {
		System.out.println("from testGetMonth");
		Date td=new Date(23,2,2017);
		assertEquals(2,td.getIntMonth());
		
	}

	@Test
	public void testgetYear() {
		System.out.println("from testGetYear");
		Date td=new Date(23,2,2017);
		assertEquals(2017,td.getIntYear());
		
	}

}
