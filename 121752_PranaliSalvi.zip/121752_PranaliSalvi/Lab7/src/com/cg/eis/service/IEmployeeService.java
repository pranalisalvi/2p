package com.cg.eis.service;

public interface IEmployeeService {
	public void inputEmployee();
	public void displayOnScheme();
	public void deleteDetails();
}
