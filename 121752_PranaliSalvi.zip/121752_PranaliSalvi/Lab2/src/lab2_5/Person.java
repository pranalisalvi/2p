package lab2_5;

public class Person {
	String firstName;
	String lastName;
	Gender gender;               //user defined datatype
	String phoneNumber;
	


	public Person(String firstName, String lastName, Gender gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}


	public Person() {            //default constructor
		super();
	}

	void show(){
		System.out.println("first name:"+firstName);
		System.out.println("last name:"+lastName);
		System.out.println("Gender:"+gender);
	}

    public  String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public Gender getGender() {
		return gender;
	}


	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}



}
