package lab2_5;

import java.util.Scanner;



public class PersonMain {

	public static void main(String[] args) {
		Gender gender=null;
		Person p=new Person();
		p.setFirstName("Divya");
		p.setLastName("Bharathi");
		
		System.out.println("enter no");
		Scanner sc=new Scanner(System.in);
		String phoneNumber=sc.nextLine();
		p.setPhoneNumber(phoneNumber);
		
		System.out.println("enter gender");
		String m_gender=sc.nextLine();           //gender is taken in String
		gender=Gender.valueOf(m_gender);         //gender which is in String converted to Enum type i.e.Gender
		p.setGender(gender);
		p.show();
		
	


	}

}
