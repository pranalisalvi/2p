package lab2_4;

import java.util.Scanner;


public class PersonMain {

	public static void main(String[] args) {
		Person p=new Person("Divya","Bharathi",'f');
		System.out.println("enter phone number");
		Scanner sc=new Scanner(System.in);
		String phoneNumber=sc.nextLine();
		p.setPhoneNumber(phoneNumber);
		p.display();
		

	}

}
