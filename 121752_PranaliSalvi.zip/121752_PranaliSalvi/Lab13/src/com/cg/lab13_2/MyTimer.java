package com.cg.lab13_2;


public class MyTimer implements Runnable {

	@Override
	public void run() {

		int i = 1;
		while (i <= 10) {
			if (i == 1) {
				System.out.println("Timmer Started");
				System.out.println(i);
				i++;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if (i==10) {
				System.out.println(i);
				i=1;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			else {	System.out.println(i);
				i++;
				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			

		}
	}

}
