package com.cg.lab13_1;

public class FileProgram {

	public static void main(String[] args) {

		CopyDataThread cp = new CopyDataThread();
		cp.start();
	}

}
