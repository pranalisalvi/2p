package lab6_2;

import java.util.Scanner;


public class Emp  {
private String name;
private int age;

public void getDetails() throws AgeException{
	System.out.println("enter name");
	Scanner sc=new Scanner (System.in);
	name=sc.next();
	System.out.println("enter age");
	int a=sc.nextInt();
	
	if(a<16){
		throw new AgeException(a);
	}
	else{
		age=a;
	}
}
}
