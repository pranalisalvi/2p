package lab6_1;

import java.util.Scanner;

public class PersonApp{
	public static void main(String[] args) throws NameException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first name");
		String name=sc.nextLine();
		System.out.println("Enter last name");
		String name2=sc.nextLine();
		
		Person p=new Person(name,name2,'f');
		System.out.println("first name:"+p.getFirstName());
		System.out.println("last name:"+p.getLastName());
		System.out.println("gender:"+p.getGender());
	}
}


			