package lab6_1;

public class NameException extends Exception{
	String firstName;
	String lastName;
	char gender;
	
	public NameException(String msg){
		super(msg);
	}
	
	
}
