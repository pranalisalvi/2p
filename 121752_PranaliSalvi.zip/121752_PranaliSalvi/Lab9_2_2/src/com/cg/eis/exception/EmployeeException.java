
	


package com.cg.eis.exception;

public class EmployeeException extends Exception {

public EmployeeException(String S){

super(S);

String msg= S;

System.out.println(msg);

}

}