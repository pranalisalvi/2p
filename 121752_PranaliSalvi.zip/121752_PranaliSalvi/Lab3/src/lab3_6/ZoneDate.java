package lab3_6;



import java.time.ZoneId; 
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneDate {


		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			
			System.out.println("1.America/New_York");
			System.out.println("2.Europe/London");
			System.out.println("3.Asia/Tokyo");
			System.out.println("4.US/Pacific");
			
			System.out.println("enter options");
			 int op=sc.nextInt();
			
		switch(op){
		case 1:
			
			ZonedDateTime currentTimeInAmericaNewYork = ZonedDateTime.now(ZoneId.of("America/New_York"));
			System.out.println("America/New York:"+ currentTimeInAmericaNewYork);
			break;
			
		case 2:
			
			ZonedDateTime currentTimeInEuropeLondon = ZonedDateTime.now(ZoneId.of("Europe/London"));
			System.out.println("Europe/London"+ currentTimeInEuropeLondon);
			break;
			
		case 3:
		
			ZonedDateTime currentTimeInAsiaTokyo = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
			System.out.println("Asia/Tokyo:"+ currentTimeInAsiaTokyo);
			break;
			
		case 4:
			ZonedDateTime currentTimeInUSPacific = ZonedDateTime.now(ZoneId.of("US/Pacific"));
			System.out.println("US/Pacific:"+ currentTimeInUSPacific);
			break;
		
		default:
			System.out.println("invalid zone id");
			break;
			
		}
			
			
			
		}
			
		}
	


