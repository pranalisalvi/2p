package lab3_5;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class Warantee {

	public static void calculateWarantee(String stringDate){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate userDate = LocalDate.parse(stringDate,formatter);
		System.out.println(" Given Purchase Date "+stringDate);
		System.out.println("Enter Warantee Period in months and years:");
		Scanner sd = new Scanner(System.in);
		int mon = sd.nextInt();
		int years = sd.nextInt();
		
		System.out.println("Warantee of product expires on");
		userDate=userDate.plusMonths(mon);
		userDate=userDate.plusYears(years);
		System.out.println(userDate);
		
		
		sd.close();
	}
	public static void main(String[] args) {
		String stringDate;
		
		System.out.println("Enter Purchase date:");
		Scanner sc = new Scanner(System.in);
		stringDate=sc.nextLine();
		
		calculateWarantee(stringDate);
		sc.close();
		

	}

}