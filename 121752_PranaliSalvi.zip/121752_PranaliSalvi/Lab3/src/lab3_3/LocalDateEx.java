package lab3_3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class LocalDateEx {
	public static void calculatePeriod(String sdate){
	DateTimeFormatter Formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate givenDate =LocalDate.parse(sdate,Formatter);
	System.out.println("Given date"+givenDate);
	LocalDate today =LocalDate.now();
	System.out.println("today"+today);
	Period period=givenDate.until(today);
	System.out.println("days:"+period.getDays());
	System.out.println("months:"+period.getMonths());
	System.out.println("years:"+period.getYears());
	

	
	}
	public static void main(String[] args) {
		String stringDate="01/01/2017";
		calculatePeriod(stringDate);
		
		/*DateTimeFormatter Formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");  //create 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter date in dd/MM/yyyy format :");
		String input =sc.nextLine();
		LocalDate enteredDate =LocalDate.parse(input,Formatter);  //string to localdate class
		LocalDate start =LocalDate.now();
		Period period=enteredDate.until(start);
		System.out.println("days:"+period.getDays());
		System.out.println("months:"+period.getMonths());
		System.out.println("years:"+period.getYears());      */
		

	}
}