package com.cg.eis.pl;

import java.util.*;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmpServiceImpl;



public class TestEmp {

	public static void main(String[] args) {

EmpServiceImpl empSr= new EmpServiceImpl();

int choice=0;

Scanner sc= new Scanner(System.in);

do{

ShowChoice();

System.out.println("Enter your choice number");

choice= sc.nextInt();

switch(choice){

case 1:

empSr.inputEmployee();

break;

case 2:

empSr.showAllEmp();

break;

case 3:

empSr.deleteEmp();

break;

case 4:

break;

default:

System.out.println("Wrong choice");

break;

}

}while(choice!=4);

}

	public static void ShowChoice() {

		System.out.println("*********************");

		System.out.println("1. Add Employee");

		System.out.println("2. Show all Employees");

		System.out.println("3. Delete Employee");

		System.out.println("4. Exit");

		System.out.println("*********************");

	}

}