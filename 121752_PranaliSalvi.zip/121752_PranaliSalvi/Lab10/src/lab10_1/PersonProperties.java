package lab10_1;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class PersonProperties {

	public static void writeProperties() {
		Properties prop = new Properties();
		OutputStream out = null;

		prop.setProperty("person.name", "Lucifer Perry");
		prop.setProperty("person.gender", "Male");
		prop.setProperty("person.country", "Canada");
		prop.setProperty("person.DOB", "29-FEB-1998");
		prop.setProperty("person.designation", "Manager");

		try {
			out = new FileOutputStream("D:\\PersonProps.properties");
			try {
				prop.store(out, null);
			} catch (IOException e) {

				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

		finally {
			try {
				out.close();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}

	}

	
	public static void readProperties() {
		Properties prop = new Properties();
		InputStream in = null;

		try {
			in = new FileInputStream("D:\\PersonProps.properties");
			try {
				prop.load(in);
			} catch (IOException e) {

				e.printStackTrace();
			}

			System.out.println("Person Name : "
					+ prop.getProperty("person.name"));
			System.out.println("Person Gender : "
					+ prop.getProperty("person.gender"));
			System.out.println("Person Country : "
					+ prop.getProperty("person..country"));
			System.out
					.println("Person DOB : " + prop.getProperty("person.DOB"));
			System.out.println("Person Designation : "
					+ prop.getProperty("person.designation"));
			// lab10.a
			System.out.println("Using Property Object:");
			System.out.println(prop);

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
		}

	}

	public static void main(String args[]) {
		writeProperties();
		readProperties();

	}

}
