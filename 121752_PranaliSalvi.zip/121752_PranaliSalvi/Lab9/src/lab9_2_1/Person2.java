package lab9_2_1;

public class Person2 {
	
	String firstName;
    String lastName;
    char gender;
	
	
	public Person2() {
		super();
	}
	public Person2(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
      
      public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
	public String displayDetails() {
		String ret="Person Details: "+firstName+" "+lastName+" "+gender;
		return ret;
	}
	
      
}
