package lab9_2_1;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestPerson2 {
	Person2 pr2;
	@Before
	public void setUp() throws Exception {
		pr2=new Person2("Pranali","Salvi",'F');
	}

	@After
	public void tearDown() throws Exception {
		pr2=null;
	}

	@Test
	public void testGetFirstName() {
		System.out.println("from testGetFirstName");
		assertEquals("Pranali",pr2.getFirstName());
	}

	@Test
	public void testGetLastName() {
		System.out.println("from testGetLastName");
		assertEquals("Salvi",pr2.getLastName());
		
	}

	@Test
	public void testGetGender() {
		System.out.println("from testGetGender");
		assertEquals('F',pr2.getGender());
	}
	
	@Test
	public void nullCheck(){
		System.out.println("NullCheck");
		Person2 pr3=null;
		assertNotNull(pr2);
		assertNull(pr3);
	}

	
	@Test
	public void testdisplayDetails(){
		System.out.println("from testdisplayDetails");
		System.out.println(pr2.displayDetails());
		assertEquals("Person Details: Pranali Salvi F", pr2.displayDetails());
	}
}
