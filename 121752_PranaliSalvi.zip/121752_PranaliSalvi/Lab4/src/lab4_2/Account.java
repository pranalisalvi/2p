package lab4_2;


public class Account {
	private	long accNum;
	private double balance;
    private Person accHolder;
    static int count=10000;             
    
   
   
	public Account() {               //creating default & para. constr since setter method not written to this
		super();
		count++;
		accNum=count;
	}

	public Account( double balance) {     //creating parametrized constr
		super();
		count++;
		this.accNum = count;
		this.balance = balance;
	}

	public Person getAccHolder() {     //getter setter for only AccHolder
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	public long getAccNum() {        //for security getter use for AccNum, Balance
		return accNum;
	}

	public double getBalance() {
		return balance;
	}
	
	
	public void deposit(double amt){   
	    	balance+=amt;
	    }
	    
	public void withdraw(double amt){
	    	balance-=amt;	
	    }

	public String toString() {       //create toString for that memory converted to value in main class
		return "Account Details [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	
	

}
