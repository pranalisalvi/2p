package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;
import com.cg.ma.exception.PurchaseDetailsException;

public class MobileServiceImpl implements IMobileService {
IMobileDao imobile=new MobileDaoImpl();
	public List<Mobile> showAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return imobile.showAll();     //add code of call method od DaoImpl
	}

	public boolean deleteMobile(int mobileid) throws MobileException {
		// TODO Auto-generated method stub
		return imobile.deleteMobile(mobileid);   //add code
	}
		

	public List<Mobile> searchMobileByRange(int start, int end)
			throws MobileException {
		// TODO Auto-generated method stub
		return imobile.searchByRange(start,end);    //add code

	}

	public boolean updateQty(int mobileid, int qty) throws MobileException {
		// TODO Auto-generated method stub
		return imobile.updateQty(mobileid, qty);      //add code
	}

	public boolean Mobileid(int mid) throws MobileException {
		
		return imobile.Mobileid(mid);
	}
	
	public boolean insertPurchaseDetails(String cust_name, String cust_mail,
			String cust_phone, int mobileid) throws PurchaseDetailsException {
		  
		  
		return imobile.insertPurchaseDetails(cust_name, cust_mail, cust_phone, mobileid);
	}

}
