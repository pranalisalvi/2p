package lab6_1;





public class Person {
	String firstName;
	String lastName;
	char gender;
	String phoneNumber;
	

	public Person(String firstName, String lastName, char gender) throws NameException {
		super();
		if(firstName.length()!=0){
		this.firstName = firstName;
	}
		else{
		throw new NameException("first must be entered");
	}
		
		
		if(lastName.length()!=0){
		this.lastName = lastName;
		}
		else{
		throw new NameException("last must be entered");
		}
		this.gender = gender;
		
	}


	public Person() {            //default constructor
		super();
	}
	
	public void display(){
		System.out.println("First name:"+firstName);
		System.out.println("lastName:"+lastName);
		System.out.println("gender:"+gender);
		System.out.println("phone no:"+phoneNumber);
	}


    public  String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) throws NameException {
		if(firstName.length()!=0){
			this.firstName = firstName;
		}
			else{
			throw new NameException("first must be entered");
		}
			
		
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) throws NameException {
		if(lastName.length()!=0){
		this.lastName = lastName;
		}
		else{
		throw new NameException("last must be entered");
		}
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


}
