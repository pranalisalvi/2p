package lab6_2;


public class EmpApp1 {

	public static void main(String[] args) {
		Emp e=new Emp();
		try {
			e.getDetails();
		} catch (AgeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

}
