package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	 Employee e;
		
		public void inputEmployee(){
			Scanner sc=new Scanner(System.in);
			System.out.println("enter id");
			int id=sc.nextInt();
			System.out.println("enter name");
			String name=sc.next();
			System.out.println("enter salary");
			double salary=sc.nextDouble();
			System.out.println("enter designation");
			String designation=sc.next();
			
		 try {
			e=new Employee(id,name,salary,designation);
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
		}
		
		public void findInsuranceScheme() {
			 String insuranceScheme=null;
			 double salary=e.getSalary();
			 String designation=e.getDesignation();
			if((salary >5000  && salary <20000) && designation.equals("System Associate"))
			 {
				 insuranceScheme="Scheme C";
			 }
			 
			 else if((salary >=20000  && salary <40000) && designation.equals("Programmer"))
			 {
				 insuranceScheme="Scheme B";
			 }
			 else if((salary>=40000) && designation.equals("Manager"))
			 {
				insuranceScheme="Scheme A";
			 }
			 else if((salary< 5000) && designation.equals("Clerk"))
			 {
				 insuranceScheme="No Scheme";
				 
				 
			 }

			e.setInsuranceScheme(insuranceScheme);
	}
			 
			
		

		public void display() {
			// TODO Auto-generated method stub
			System.out.println(e);
			
		}

		
		

		
		
	}

