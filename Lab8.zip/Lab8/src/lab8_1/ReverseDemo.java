package lab8_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseDemo{
	public static void main(String args[]){
		try(FileReader in=new FileReader("d:\\word.txt");FileWriter out=new FileWriter("d:\\copypath.txt")) {
			int ch;
			File f=new File("d:\\word.txt");
			int len=(int)f.length();
			char arr[]=new char[len];
			int i=0;
			ch=in.read();
			while(ch!=-1){
				arr[i]=(char) ch;
				i++;
				ch=in.read();
			}
			for(int j=len-1;j>0;j--){
				System.out.print(arr[j]);
				out.write(arr[j]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

