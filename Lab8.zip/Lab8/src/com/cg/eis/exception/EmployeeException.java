package com.cg.eis.exception;

public class EmployeeException extends Exception{
	
	private double salary;

	public EmployeeException(double salary) {
		super();
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return "EmloyeeException [salary=" + salary + "]";
	}


}
