package com.cg.eis.service;

import com.cg.eis.exception.EmployeeException;

public interface IEmployeeService {

	public void inputEmployee();
	public void findInsuranceScheme();
	public void display();
	public void writeData();
	public void readData();
	
}

