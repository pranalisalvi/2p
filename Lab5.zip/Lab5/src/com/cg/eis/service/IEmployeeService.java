package com.cg.eis.service;

public interface IEmployeeService {
	public void inputEmployee();
	public void findInsuranceScheme();
	public void display();

}
