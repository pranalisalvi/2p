package lab5_3;

public class CurrentAccount extends Account {
private int overDraft=10000;
	
	
	public CurrentAccount(double balance) {
		super(balance);
	}


	@Override
	public void withdraw(double amt) {
		double balance=getBalance();
		if((balance-amt) >= overDraft){
			balance-=amt;
		}
		else{
			System.out.println("balance should be minimum of RS.500");
		}
	}
	
		
	}
	
	

	


