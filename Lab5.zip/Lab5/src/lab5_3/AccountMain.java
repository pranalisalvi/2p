package lab5_3;


public class AccountMain {

	public static void main(String[] args) {
		Person smith=new Person("Smith",23);
		Person kathy=new Person("Kathy",25);
		
		Account smithAccount=new SavingAccount(8000);
		smithAccount.setAccHolder(smith);
		System.out.println(smithAccount);              //bcoz of toString() we call smithAccount directly,otherwise it will it return memory not values
		
		
		Account kathyAccount=new CurrentAccount(3000);
		kathyAccount.setAccHolder(kathy);
		System.out.println(kathyAccount);
		
		smithAccount.withdraw(7000);
		kathyAccount.deposit(5000);
		
		System.out.println("Updated balance of smith:"+smithAccount.getBalance());
		System.out.println("Updated balance of kathy:"+kathyAccount.getBalance());
		
		
	}

}
