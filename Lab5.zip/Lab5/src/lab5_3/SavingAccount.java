package lab5_3;

public class SavingAccount extends Account {

	
	final public int minBal=500;

	

	public SavingAccount(double balance){
		super(balance);
	}

	@Override
	public void withdraw(double amt) {
		double balance=getBalance();
		if((balance-amt) >= minBal){
			balance-=amt;
		}
		else{
			System.out.println("balance should be minimum of RS.500");
		}
	}
		
	}

	
		


