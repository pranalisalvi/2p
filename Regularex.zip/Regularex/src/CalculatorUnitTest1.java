import java.util.Arrays;
import java.util.Collection;

import org.junit.Assert;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;



@RunWith(Parameterized.class)
public class CalculatorUnitTest1 {
	@Parameterized.Parameters
	public static Collection data(){
		return Arrays.asList(new Object[][] {{2,5,7},{3,3,6},{5,4,9}});
		
		
	}
	
	 private int input1;
	 private int input2;
     private int expected;
	
     public CalculatorUnitTest1(int input1, int input2, int expected) {
		this.input1 = input1;
		this.input2 = input2;
		this.expected = expected;
	}
     
     public void testMethod(){
    	 System.out.println("running prametrized test");
    	 Assert.assertEquals(expected, Calculator1.add(input1,input2));
     }
     
     

}
