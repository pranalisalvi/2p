import static org.junit.Assert.*;

import org.junit.Test;


public class Testadd {

	@Test
	public void test() {
		Calculator1 cal=new Calculator1();
		assertEquals(7,cal.add(2, 5));
	}

}
