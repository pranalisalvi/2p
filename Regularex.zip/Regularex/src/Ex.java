import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Ex {
	public static void main(String[] args){
		
//String s="123/1234/123";
//Pattern pattern=Pattern.compile("^[0-9]{3}(_|/)[0-9]{4}(_|/)[0-9]{3}$");
		
		//ANY char without space
String s="Ana";
//Pattern pattern=Pattern.compile("^[A-za-z0-9.\\S]+$");
String nonspace="^[\\S]+$";
System.out.println(Pattern.matches(nonspace, s));

//Matcher matcher=pattern.matcher(s);
//System.out.println(matcher.matches());
}
}
