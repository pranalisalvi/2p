package lab4_2;


public class SavingAccount extends Account {
	final public int minBal=500;

public SavingAccount() {
	super();	
}

public SavingAccount(double balance) {
	super(balance);
}

@Override
public void withdraw(double amt) {
	double balance=getBalance();
	if((balance-amt) >= minBal){
		super.withdraw(amt);
	}
	else{
		System.out.println("balance should be minimum of RS.500");
	}
}
}
