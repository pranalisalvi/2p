package lab4_2;

public class CurrentAccount extends Account{
     
	private int overDraft=10000;
	
	public CurrentAccount() {
		super();
	}

	public CurrentAccount(double balance) {
		super(balance);
	}

	@Override
	public void withdraw(double amt) {
		
		double balance=getBalance();
		if((amt-balance) < overDraft){
			super.withdraw(amt);
		}
		else{
			System.out.println("overdraft limit exceeded");
		}
	}    
  
}
