
class StDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String Day = args[0];
		switch (Day) {
		case "MONDAY":
		case "TUESDAY":
		case "WEDNESDAY":
			System.out.println("boring");
			break;
		case "THURSDAY":
			System.out.println("getting better");
			break;
		case "FRIDAY":
		case "SATURDAY":
		case "SUNDAY":
			System.out.println("much better");
			break;
	}

}
}
