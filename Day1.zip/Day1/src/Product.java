import org.junit.Test;


public class Product {
	private int no;
	private String pname;
	private int qty;
	private double price;
	public Product() {
		super();
	}
	public Product(int no, String pname, int qty, double price) {
		super();
		this.no = no;
		this.pname = pname;
		this.qty = qty;
		this.price = price;
	}
	
	@Test
	public double calculateCost(){
		double cost=qty*price;
		cost=cost-(cost*0.1);
		return cost;
	}
	
	@Test
	public Product get(){
		return new Product();
	}
		
	}

