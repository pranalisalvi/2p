import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ProductTest {
	Product p;
	Product p1;
	@Before
	public void setUp() throws Exception {
		p=new Product(1,"Pen",10,10);
		p1=p;
	}

	@After
	public void tearDown() throws Exception {
		p=null;
	}

	@Test
	public void testCalculateCost() {
		assertEquals(95,p.calculateCost(),0.0);
	}

	public void testGet(){
		assertNotNull(p.get());
	}
	
	public void testSame(){
		assertSame(p,p1);
	}
}
