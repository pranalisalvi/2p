
public class TestMyClass {

	public static void main(String[] args) {
		
MyInterface mInterface=(x,y) ->x+y;
System.out.println(mInterface.add(4,6));
	}

}
