@FunctionalInterface
public interface MyInterface {
  public int add(int x,int y);
}
