package lab2_2;


public class PositiveOrNegative {

	public static void main(String[] args) {
		int n=Integer.parseInt(args[0]);
		if (n>0) {
			System.out.println("positive number");
			
		} else {
			System.out.println("negative number");

		}
		
		
		// TODO Auto-generated method stub

	}

}
