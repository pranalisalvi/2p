package lab2_4;

public class Person {
	String firstName;
	String lastName;
	char gender;
	String phoneNumber;
	

	public Person(String firstName, String lastName, char gender){
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		
	}


	public Person() {            //default constructor
		super();
	}
	
	public void display(){
		System.out.println("First name:"+firstName);
		System.out.println("lastName:"+lastName);
		System.out.println("gender:"+gender);
		System.out.println("phone no:"+phoneNumber);
	}


    public  String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
			this.firstName = firstName;			
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


}


