package lab2_5;

public enum Gender {
		F("F"),M("M");
		String value;

		private Gender(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}

		/*public void setValue(String value) {
			this.value = value;
		}*/ //setter is not used bcz value is fixed.
		
		

	
}

