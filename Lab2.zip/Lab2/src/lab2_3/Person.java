package lab2_3;

public class Person {
	
	String firstName;
	String lastName;
	char gender;
	
	public Person(String firstName, String lastName, char gender) {      //Parametrized constructor
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}


	public Person() {            //default constructor
		super();
	}


    public  String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


}
