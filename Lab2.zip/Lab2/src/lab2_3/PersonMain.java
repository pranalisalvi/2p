package lab2_3;

public class PersonMain {

	public static void main(String[] args) {
		

			
				Person p=new Person("Divya","Bharathi",'f');
				System.out.println("first name:"+p.getFirstName());
				System.out.println("last name:"+p.getLastName());
				System.out.println("gender:"+p.getGender());
				
			

		

	}

}
