package lab3_1;

public class UserOperation {

	String values;
	String option;
	public UserOperation() {
		super();
	}
	public UserOperation(String values, String option) {
		super();
		this.values = values;
		this.option = option;
	}
	public String getValues() {
		return values;
	}
	public void setValues(String values) {
		this.values = values;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	
	
	
	void display(){
		
		switch(option){
		case "1":
			toAppend(values);
			break;
		case "2":
			toReplace(values);
			break;
		case "3":
			toRemoveDuplicate(values);
			break;
		case "4":
			toOddCharacters(values,option);
			break;
		case "5":
			System.exit(0);
			break;
			
		default:
			System.out.println("Invalid Choice");
			break;
		}
	}
	void toAppend(String values){
		values=values.concat(values);
		System.out.println(values);
	}
	
	void toReplace(String values){
		String demo=values;
		int len=demo.length();
		for(int i=0;i<=len;i++)
		{
			if(i%2!=0)
			{
				demo=demo.substring(0,i-1)+"#"+demo.substring(i,len);
			}
		}
		System.out.println(demo);
	}
	
	void toRemoveDuplicate(String values){
		String string=values;
		int strlen=string.length();
		String noDuplicate="";
		char ch;
		for(int i=0;i<strlen;i++){
			ch=string.charAt(i);
			if(ch!=' '){
				noDuplicate=noDuplicate+ch;
			}
			string=string.replace(ch, ' ' );
		}
		System.out.println("String after removing duplicate characters is: "+noDuplicate);
	}
	
	void toOddCharacters(String values, String option){
		
		StringBuilder ns=new StringBuilder(values);
		int newLength=ns.length();
		for(int i=0;i<newLength;i++){
				if(i % 2 == 0){
					char c=ns.charAt(i);
					ns.setCharAt(i,Character.toUpperCase(c));
				}
		}
		String result = new String(ns);
		System.out.println(result);
	}

}
