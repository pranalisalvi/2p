package lab3_1;

import java.util.Scanner;
public class Operations {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String:");
		String userString = sc.nextLine();
		System.out.println("Enter your Choice:");
		System.out.println("1. Apend the string");
		System.out.println("2. Replace odd positions with #");
		System.out.println("3. Remove Duplicate characters from string");
		System.out.println("4. Change odd characters to uppercase");
		System.out.println("5. Exit");
		String choice=sc.nextLine();
		UserOperation choices = new UserOperation(userString,choice);
		sc.close();
		choices.display();
		
	}
}