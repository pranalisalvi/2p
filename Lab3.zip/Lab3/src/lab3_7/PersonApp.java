package lab3_7;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;



public class PersonApp {

	public static void main(String[] args) {
		Person p=new Person("Divya","Bharathi",'f');
		
		System.out.println("first name:"+p.getFirstName());
		System.out.println("last name:"+p.getLastName());
		System.out.println("Gender:"+p.getGender());
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter dob");
		String birthDate=sc.next();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dob = LocalDate.parse(birthDate,formatter);
		p.setDob(dob);
		displayAge(dob);
		
		String fName=p.getFirstName();
		String lName=p.getLastName();
		getFullName(fName,lName);
	}
	
	
	public static void getFullName(String fName,String lName){
		String fullName;
		fullName=fName.concat(lName);
		System.out.println("full name:"+fullName);

	}

	public static void displayAge(LocalDate dob){
		LocalDate today=LocalDate.now();
		Period period=dob.until(today);
		System.out.println("age:"+period.getYears()+"yrs:");
	}
}
