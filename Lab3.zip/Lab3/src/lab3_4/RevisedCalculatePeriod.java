package lab3_4;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class RevisedCalculatePeriod {

	public static void main(String[] args) {
		DateTimeFormatter Formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter date in dd/MM/yyyy format :");
		String input1 =sc.nextLine();
		LocalDate start =LocalDate.parse(input1,Formatter);
		System.out.println("Enter date in dd/MM/yyyy format :");
		String input2 =sc.nextLine();
		LocalDate end =LocalDate.parse(input2,Formatter);
		Period period=start.until(end);
		System.out.println("days:"+period.getDays());
		System.out.println("months:"+period.getMonths());
		System.out.println("years:"+period.getYears());
		

		

	}

}
