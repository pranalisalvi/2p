package com.cg.eis.service;

import java.sql.Connection;

import com.cg.eis.service.IEmployeeService;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.eis.util.JdbcUtil;

public class EmployeeServiceImpl implements IEmployeeService {

	Employee emp;

	Connection con;

	PreparedStatement pst;

	public boolean inputEmployee() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter number of Employees: ");

		int n = sc.nextInt();

		for (int i = 0; i < n; i++) {

			System.out.println("Enter id: ");

			int empid = sc.nextInt();

			System.out.println("Enter name: ");

			String name = sc.next();

			System.out.println("Enter Salary: ");

			double salary = sc.nextDouble();

			System.out.println("Enter designation: ");

			String designation = sc.next();
			
			
			
			

			con = JdbcUtil.getConnection();

			int rec = 0;

			String query = "Insert into employee10_2 values(?,?,?,?.?)";

			try {

				pst = con.prepareStatement(query);

				pst.setInt(1, empid);

				pst.setString(2, name);

				pst.setDouble(3, salary);

				pst.setString(4, designation);

				rec = pst.executeUpdate();

				if (rec > 0) {

					return true;

				}

			} catch (SQLException e) {

				e.printStackTrace();

			}

		}
		return false;

	}

	public List<Employee> ShowAllData() {

		con = JdbcUtil.getConnection();

		String query = "SELECT * from employee10_2";

		List<Employee> mlist = new ArrayList<Employee>();

		try {

			pst = con.prepareStatement(query);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				int m_id = rs.getInt(1);

				String m_name = rs.getString(2);

				double m_salary = rs.getInt(3);

				String m_designation = rs.getString(4);

				Employee m = new Employee();

				m.setId(m_id);

				m.setName(m_name);

				m.setSalary(m_salary);

				m.setDesignation(m_designation);

				mlist.add(m); // add object m to arraylist mlist

			}

			for (Employee e : mlist) {

				System.out.println(e);

			}

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} finally {

		}

		try {

			pst.close();

			con.close();

		} catch (SQLException e) {

			e.printStackTrace();

		}

		return mlist;

	}

	@SuppressWarnings("finally")
	public boolean deleteDetails(int empid) {
		con = JdbcUtil.getConnection();

		String query = "DELETE FROM employee10_2 where empid=?";

		try {

			pst = con.prepareStatement(query);

			pst.setInt(1, empid);

			int rec = pst.executeUpdate();

			if (rec > 0) {

				return true;

			}

		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			try {

				pst.close();

				con.close();

			} catch (SQLException e) {

				// TODO Auto-generated catch block

				e.printStackTrace();

			}

			return false;
		}

	}
}
