package com.cg.eis.service;
import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.IEmployeeService;

public interface IEmployeeService {
	public boolean inputEmployee();
	public List<Employee> ShowAllData();
	public boolean deleteDetails(int id);
}
