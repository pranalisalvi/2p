package com.cg.eis.pl;



import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;

public class EmpApp {
	public static void main(String[] args){
	IEmployeeService service=new EmployeeServiceImpl();
	service.inputEmployee();
	service.ShowAllData();
	service.deleteDetails(301);
}
}

