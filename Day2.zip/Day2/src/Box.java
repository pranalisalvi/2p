


public class Box {
	double dblWidth;
	double dblHeight;
	double dblDepth;
	static int count;

	public Box(double dblWidth, double dblHeight, double dblDepth) {
		super();
		this.dblWidth = dblWidth;
		this.dblHeight = dblHeight;
		this.dblDepth = dblDepth;
		count++;
	}

	public Box() {
		super();
		count++;
		//dblWidth = dblHeight = dblDepth = 0.0
	}

	
	static void showCount(){
		System.out.println("count:"+count);
	}
		
		

	public double getDblWidth() {
		return dblWidth;
	}

	public void setDblWidth(double dblWidth) {
		this.dblWidth = dblWidth;
	}

	public double getDblHeight() {
		return dblHeight;
	}

	public void setDblHeight(double dblHeight) {
		this.dblHeight = dblHeight;
	}

	public double getDblDepth() {
		return dblDepth;
	}

	public void setDblDepth(double dblDepth) {
		this.dblDepth = dblDepth;
	}
}//class Box ends.


class BoxDemo {
	public static void main(String a[]) {
		Box box1; //declare a reference to object
		box1 = new Box(); //allocate a memory for box object.
		System.out.println();
		
		Box box2 = new Box(10,20,30);		//invoke constructor
		System.out.println();
		
	} 
}
	


