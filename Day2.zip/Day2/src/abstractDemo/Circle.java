package abstractDemo;

public class Circle extends Shape {
	private int radius;

	public Circle() {
		super();
		int radius=3;
	}
@Override
	public void draw() {
		System.out.println("circle is drawn");
		
	}

	
}
