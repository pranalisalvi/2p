package abstractDemo;

public class Vehicle {
	private String regNo;
	private String model;
	private int price;
	
	
	public Vehicle() {
		super();
	}
	public Vehicle(String regNO, String model, int price) {
		super();
		this.regNo = regNO;
		this.model = model;
		this.price = price;
	}
	
	public void start(){
		System.out.println("vehicle is started");
	}
	
	public void stop(){
		System.out.println("vehicle is stopped");
	}
	
	public void show(){
		System.out.println(" "+regNo+" "+model+" "+price);
	}

}
