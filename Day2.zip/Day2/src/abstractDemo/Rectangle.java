package abstractDemo;

public class Rectangle  extends Shape{
	
	private int length;
	private int breadth;
	
	
	public Rectangle() {
		super();
		int length=50;
		int breadth=80;
	}
	
	@Override
	public void draw() {
		System.out.println("Rectangle is drawn");
		
	}


	

}
