package abstractDemo;


public class TestVehicle {

			public static void main(String[] args) {
			Vehicle v=new Car("MH4001","BMW",25000,5);
				v.show();
				v.start();
				v.stop();
				
			Vehicle v1=new Truck("Moo28","Mahindra",7923,9);
				v1.show();
				v1.start();
				v1.stop();
				
			}

		}




