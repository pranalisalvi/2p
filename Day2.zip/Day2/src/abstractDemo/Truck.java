package abstractDemo;

public class Truck extends Vehicle{
	@Override
	public void start() {
		System.out.println("Truck is started");
		super.start();
	}

	@Override
	public void stop() {
		System.out.println("Truck is stopped");
		super.stop();
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		super.show();
	}

	private int noOfPassenger;

	public Truck(String regNO, String model, int price, int noOfPassenger) {
		super(regNO, model, price);
		this.noOfPassenger = noOfPassenger;
	}
	
	

	
	

}
