package abstractDemo;

public class Triangle extends Shape {
	

	private int base;
	private int height;
	
	
	public Triangle() {
		super();
		int base=45;
		int height=55;
	}

	@Override
	public void draw() {
		System.out.println("Triangle is drawn");
		
	}

	

}
