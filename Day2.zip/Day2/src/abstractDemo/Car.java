package abstractDemo;

public class Car extends Vehicle {
	@Override
	public void start() {
		System.out.println("Car is started");
		super.start();
	}

	@Override
	public void stop() {
		System.out.println("Car is stopped");
		super.stop();
	}

	@Override
	public void show() {
		
		super.show();
	}

	private int noOfPassenger;

	public Car(String regNO, String model, int price, int noOfPassenger) {
		super(regNO, model, price);
		this.noOfPassenger = noOfPassenger;
	}


	
	

	

}
