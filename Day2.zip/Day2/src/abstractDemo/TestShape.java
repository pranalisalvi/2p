package abstractDemo;

import java.util.Random;

public class TestShape {

	public static void main(String[] args) {
		Shape shapes[]=new Shape[5];
		shapes[0]=new Rectangle();
		shapes[1]=new Circle();
		shapes[2]=new Triangle();
		shapes[3]=new Circle();
		shapes[4]=new Triangle();
		
		
		
		/*Random r=new Random();
		
		for(int i=0;i<shapes.length;i++){
		int n=r.nextInt(3);
		switch(n){
		case 0:
			shapes[i]=new Rectangle();
			break;
		case 1:
			shapes[i]=new Circle();
			break;
		case 2:
			shapes[i]=new Triangle();
			break;	
		}
		}
		*/
		for(int i=0;i<shapes.length;i++){
			shapes[i].draw();
		}

	}

}
