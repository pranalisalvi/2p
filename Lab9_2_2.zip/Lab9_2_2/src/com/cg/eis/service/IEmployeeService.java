package com.cg.eis.service;




public interface IEmployeeService {

public void inputEmployee();

public void findScheme();

public void displayDetail();

}
