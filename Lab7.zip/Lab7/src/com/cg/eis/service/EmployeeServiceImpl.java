package com.cg.eis.service;
import java.util.HashMap; 
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;


import com.cg.eis.bean.Employee;
import com.sun.javafx.collections.MappingChange.Map;

public class EmployeeServiceImpl  implements IEmployeeService{
     Scanner sc=new Scanner(System.in);
	Employee e;
  
HashMap<Integer,Employee> hm=new HashMap<Integer,Employee>();


	public void inputEmployee(){
		Employee e1=new Employee(124,"Lara",19000,"System Associate");
		hm.put(1, e1);
		Employee e2=new Employee(125,"Sara",25000,"Programmer");
		hm.put(2, e2);
		Employee e3=new Employee(126,"Manasi",45000,"Manager");
		hm.put(3,e3);
		Employee e4=new Employee(127,"Malvika",2000,"Clerk");
		hm.put(4, e4);
		/*Set set = hm.entrySet();

		// Get an iterator
		Iterator i = set.iterator();

		// Display elements
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry)i.next();
			System.out.println(me.getKey() + ": " + me.getValue());
		}
		}*/
		System.out.println(hm);
	}
	
	public void displayOnScheme(){
		System.out.println();
		System.out.println("Enter insurance scheme ");
		String insur=sc.nextLine();
		
		for(int j=1;j<=hm.size();j++){
			String test=hm.get(j).getInsuranceScheme();
			if(insur.equals(test)){
				System.out.println(hm.get(j));
			}
		}
	}
			
		public void deleteDetails(){
			System.out.println();
			System.out.println();
			System.out.println("enter isurance scheme to delete");
			String insur=sc.nextLine();
		for(int j=1;j<=hm.size();j++){
			String test=hm.get(j).getInsuranceScheme();
			if(insur.equals(test)){
				hm.remove(j);
				}
			}
		System.out.println();
		System.out.println();
		System.out.println("after deleting");
		/*Set set=hm.entrySet();
		Iterator i=set.iterator();
		while(i.hasNext()){
			Map.Entry me=(Map.Entry)i.next();
			System.out.println(me.getKey()+":"+me.getValue());*/
		
		System.out.println(hm);
		
	}
			
	
}
