package lab7_1;

import java.util.Arrays;

public class StringArraySort {  
	public static void main(String[] args) {
		String names[]={"zzz","bbb","aaa"};
		for(String s:names){
			System.out.println(s);
		}
		System.out.println("after sort");
		Arrays.sort(names);   //Arrays class present in util pkg
		for(String s:names){
			System.out.println(s);
		}
	}
}
    