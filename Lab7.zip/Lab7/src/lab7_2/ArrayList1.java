package lab7_2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public class ArrayList1 {
	public static void main(String args[]) {
		
		List<String> al = new ArrayList<String>();
		System.out.println("Initial size of al: " + al.size());

		
		al.add("TV");
		al.add("CAMERA");
		al.add("MOBILE");
		al.add("MICROWAVE");
		
		System.out.println("Size of al after additions: " + al.size());
		
		Collections.sort(al);          //for sorting 
		for(String s:al){
			System.out.println(s);
		}

}
}
