package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.EnquiryException;
import com.capgemini.contactbook.util.JdbcUtil;

public class ContactBookDaoImpl implements ContactBookDao {
	private static final Logger mylogger = // create obj of Logger
	Logger.getLogger(ContactBookDaoImpl.class);

	@Override
	public int addEnquiry(EnquiryBean enqry) throws EnquiryException {

		Connection conn = null;
		PreparedStatement pstm = null;

		int eId = 0;
		int enqryId = 0;
		String query = "INSERT INTO ENQUIRY VALUES(?,?,?,?,?,?)";

		try {
			eId = getenquiryId();
			conn = JdbcUtil.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, eId);
			pstm.setString(2, enqry.getfName());
			pstm.setString(3, enqry.getlName());
			pstm.setString(4, enqry.getContactNo());
			pstm.setString(5, enqry.getpDomain());
			pstm.setString(6, enqry.getpLocation());

			int status = pstm.executeUpdate();
			if (status == 1) {
				mylogger.info("Enquiry Id is " + eId);
				enqryId = eId;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EnquiryException("Data not inserted...");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return enqryId;
	}//end of method

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws EnquiryException {
		Connection conn = null;
		PreparedStatement pstm = null;
		EnquiryBean enqry1 = new EnquiryBean();
		String query = "SELECT * FROM ENQUIRY WHERE enqryId=? ";

		try {
			conn = JdbcUtil.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, EnquiryID);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {

				enqry1.setEnqryId(res.getInt("enqryId"));
				enqry1.setfName(res.getString("firstName"));
				enqry1.setlName(res.getString("lastName"));
				enqry1.setContactNo(res.getString("contactNo"));
				enqry1.setpDomain(res.getString("domain"));
				enqry1.setpLocation(res.getString("city"));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EnquiryException("Data not Displayed");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return enqry1;
	}//end of method

	public static int getenquiryId() {
		int id = 0;
		String query = "SELECT enquiries.NEXTVAL FROM DUAL";
		Connection conn = null;
		PreparedStatement pstm = null;

		try {
			conn = JdbcUtil.getConnection();
			pstm = conn.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				id = res.getInt(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return id;

	}//end of method

}
