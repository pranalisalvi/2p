package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.EnquiryException;

public interface ContactBookDao {
	public int addEnquiry(EnquiryBean enqry) throws EnquiryException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws EnquiryException;
}
