package com.capgemini.contactbook.exception;

public class EnquiryException extends Exception {
	
	public EnquiryException() {
		
		super();
	}
	
	public EnquiryException(String msg){
		super(msg);
	}

}
