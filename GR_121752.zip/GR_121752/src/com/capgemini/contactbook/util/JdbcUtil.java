package com.capgemini.contactbook.util;



import java.io.FileInputStream; 
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class JdbcUtil {
	
	private static final Logger mylogger=                //create obj of logger
			Logger.getLogger(JdbcUtil.class);
	
public static Properties loadProperty(){   
	Properties prop=new Properties();       
	InputStream in=null;
	try {
		in=new FileInputStream("oracle.properties");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		prop.load(in);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return prop;
}                                        


   public static Connection getConnection() {
	   Connection con=null;
	   Properties prop=loadProperty();
	   String url=prop.getProperty("oracle.url");
	   String driver=prop.getProperty("oracle.driver");
	   String uname=prop.getProperty("oracle.uname");
	   String upass=prop.getProperty("oracle.upass");
	   try{
		   Class.forName(driver);
		   mylogger.info("Driver is loaded");    
	   }catch(ClassNotFoundException e){
		   e.printStackTrace();
		   mylogger.error("Driver is not loaded");   
	   }
	   try{
	   con=DriverManager.getConnection(url,uname,upass);
	   mylogger.info("connected to databse");           
	   }catch(SQLException e){
		  // e.printStackTrace();
		   mylogger.error("not connected");             
		   //throw new MobileException("connection problem");
   }
   
       return con;

}
}