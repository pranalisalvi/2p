package com.capgemini.contactbook.ui;

import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.EnquiryException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class Client {
	ContactBookService service = new ContactBookServiceImpl();
	public static void main(String[] args) {
		ContactBookService service = new ContactBookServiceImpl();
		int choice = 0;
		do {
			printDetail();
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			switch (choice) {
			case 1:// ADD
				String patt = "^[A-Z][a-z]{2,9}$";
				System.out.println(" Enter First Name");

				String fName1 = scr.next();
				try {
					ContactBookServiceImpl.validateName(patt, fName1);
				} catch (EnquiryException e1) {
					// e1.printStackTrace();
					System.out.println(e1.getMessage());
					break;
				}
				String patt1 = "^[A-Z][a-z]{2,9}$";
				System.out.println(" Enter Last Name");

				String lName1 = scr.next();
				try {
					ContactBookServiceImpl.validateName(patt, lName1);
				} catch (EnquiryException e1) {
					// e1.printStackTrace();
					System.out.println(e1.getMessage());
					break;
				}

				
				String patt4 = "[7|9|8]{1}[0-9]{9}";
				System.out.println(" Enter Contact Number");

				String pNo = scr.next();
				try {
					ContactBookServiceImpl.validateNo(patt4, pNo);
				} catch (EnquiryException e1) {
					// e1.printStackTrace();
					System.out.println(e1.getMessage());
					break;
				}

				

				String patt2 = "^[A-Z][a-z]{2,9}$";
				System.out.println(" Enter Preferred Domain");

				String domain = scr.next();
				try {
					ContactBookServiceImpl.validateName(patt, domain);
				} catch (EnquiryException e1) {
					// e1.printStackTrace();
					System.out.println(e1.getMessage());
					break;
				}

				String patt3 = "^[A-Z][a-z]{2,9}$";
				System.out.println(" Enter Preferred Location");

				String city = scr.next();
				try {
					ContactBookServiceImpl.validateName(patt, city);
				} catch (EnquiryException e1) {
					// e1.printStackTrace();
					System.out.println(e1.getMessage());
					break;
				}

				EnquiryBean enqry = new EnquiryBean();
				
				enqry.setfName(fName1);
				enqry.setlName(lName1);
				enqry.setContactNo(pNo);
				enqry.setpDomain(domain);
				enqry.setpLocation(city);

				try {
					int enqryId = service.addEnquiry(enqry);
					if (enqryId > 0) {
						System.out.println("Thank you your Unique id is "
								+ enqryId + " we will contact you shortly");
					} else {
						System.out.println("Data Not Inserted");
					}
				} catch (EnquiryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
				break;

			case 2:
				System.out.println("Enter Employee Id");
				int id = scr.nextInt();

				EnquiryBean enqry1 = null;
				try {
					enqry1 = service.getEnquiryDetails(id);
				} catch (EnquiryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if (enqry1.getEnqryId() >= 1001) {
					System.out.println("Id    " + "First Name      "
							+ "Last Name    " + "Contact No.   "
							+ "Preferred Domain   " + "Preferred Location   ");

					System.out.println(enqry1.getEnqryId() + "    "
							+ enqry1.getfName() + "          "
							+ enqry1.getlName() + "        "
							+ enqry1.getContactNo() + "           "
							+ enqry1.getpDomain() + "                  "
							+ enqry1.getpLocation() + "     ");

				} else {
					System.out.println("Enquiry Id is not correct");
				}
				break;

			case 3:// Exit

				break;

			}

		} while (choice != 3);

	}

	public static void printDetail() {
		System.out.println("**********");
		System.out.println("Choose an operation");
		System.out.println("1.Enter Enquiry Details ");
		System.out.println("2. View Enquiry Details on Id");
		System.out.println("3. Exit");
		System.out.println("***********");
	}

}