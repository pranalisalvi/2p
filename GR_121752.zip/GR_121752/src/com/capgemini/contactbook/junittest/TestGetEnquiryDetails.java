package com.capgemini.contactbook.junittest;

import static org.junit.Assert.*; 

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.EnquiryException;

public class TestGetEnquiryDetails {
	ContactBookDao cdao;
	@Before
	public void setUp() throws Exception {
		cdao=new ContactBookDaoImpl();
	}
	

	@Test
	public void test() {
		try {

			assertNotNull(cdao.getEnquiryDetails(1008));

		} catch (EnquiryException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}

	@After
	public void tearDown() throws Exception {
		cdao=null;

	}

}
