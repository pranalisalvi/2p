package com.capgemini.contactbook.junittest;

import static org.junit.Assert.*; 

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.EnquiryException;

public class TestaddEnquiry {
ContactBookDao cdao;
	@Before
	public void setUp() throws Exception {
		cdao=new ContactBookDaoImpl();
	}

	
	@Test
	public void testAddEnquiry() {
		EnquiryBean enqry = new EnquiryBean(1008,"Pratik","Dhuri","8693333333","Java","Pune");

		try {

			int res = cdao.addEnquiry(enqry);

			assertEquals(1008, res);

		} catch (EnquiryException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

	}
	
	@After
	public void tearDown() throws Exception {
		cdao=null;
	}


}
