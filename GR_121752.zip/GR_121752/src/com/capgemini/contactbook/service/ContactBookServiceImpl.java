package com.capgemini.contactbook.service;

import java.util.regex.Pattern; 

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.EnquiryException;


public class ContactBookServiceImpl implements ContactBookService {
	ContactBookDao dao;
	
	
	public ContactBookServiceImpl() {
		super();
		dao= new ContactBookDaoImpl();
	
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws EnquiryException {
		
		return dao.addEnquiry(enqry);
	}
	
	
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws EnquiryException {
		// TODO Auto-generated method stub
		return dao.getEnquiryDetails(EnquiryID);
	}


	public static void validateName
	(String patt,String name) throws EnquiryException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new EnquiryException("Value cannot be matched");
	}
		
	}

	public static void validateNo
	(String patt,String name) throws EnquiryException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new EnquiryException("Value cannot be matched");
	}
		
	}


}

