CREATE TABLE enquiry(
enqryId Number Primary Key,
firstName Varchar2(20),
lastName Varchar2(20),
contactNo Number(10),
domain varchar2(20),
city varchar2(20)

);


CREATE SEQUENCE enquiries
MINVALUE 1001
MAXVALUE 9999
START WITH 1001
INCREMENT BY 1
NOCACHE;

select * from ENQUIRY; 